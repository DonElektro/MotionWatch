/* This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
 * If a copy of the MPL was not distributed with this file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * MoveEye (Spielesammlung GS-1.17): on-screen arrow keys for phones and tablets. Added to A Dark Room, not part of the
 * original game. Only on touch devices, only where the game needs arrow keys: the world map («A Barren World», one step
 * per tap, holding repeats) and the flight into space (held like a key). Hidden during events (fights, places) so it never
 * covers the game's buttons. It sends the same keydown / keyup (keyCode 37-40) to <body> that the game's jQuery handlers
 * listen for. Same look as touchpad.js of the other games; sized and placed against the visual viewport because the game
 * page has no viewport meta (iOS shows it zoomed out to 980 px).
 */
(function () {
  var touch = ("ontouchstart" in window) || (navigator.maxTouchPoints > 0) || (window.matchMedia && matchMedia("(pointer:coarse)").matches);
  if (!touch || window.__mwPad) return;
  window.__mwPad = 1;
  var NAMES = {37: "ArrowLeft", 38: "ArrowUp", 39: "ArrowRight", 40: "ArrowDown"};
  var BTN = 54, GAP = 4, EDGE = 12;            // screen px (as if the page were not zoomed)
  function fire(type, kc) {
    var ev;
    try { ev = new KeyboardEvent(type, {key: NAMES[kc], code: NAMES[kc], bubbles: true, cancelable: true}); }
    catch (e) { ev = document.createEvent("Event"); ev.initEvent(type, true, true); }
    try { Object.defineProperty(ev, "keyCode", {get: function () { return kc; }}); Object.defineProperty(ev, "which", {get: function () { return kc; }}); } catch (e) {}
    (document.body || document).dispatchEvent(ev);
  }
  var css = document.createElement("style");
  css.textContent = "#mw-dpad{position:fixed;z-index:99999;display:none;grid-template-columns:repeat(3,calc(" + BTN + "*var(--u)));" +
    "grid-template-rows:repeat(3,calc(" + BTN + "*var(--u)));gap:calc(" + GAP + "*var(--u));touch-action:none;user-select:none;-webkit-user-select:none;" +
    "-webkit-touch-callout:none}#mw-dpad.on{display:grid}" +
    "#mw-dpad button{margin:0;padding:0;width:100%;height:100%;border-radius:50%;border:calc(2*var(--u)) solid rgba(255,255,255,.55);" +
    "background:rgba(20,30,45,.55);color:#fff;font:700 calc(22*var(--u)) system-ui,sans-serif;line-height:1;touch-action:none;" +
    "-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}#mw-dpad button.on{background:rgba(59,140,255,.75)}" +
    "#mw-dpad .u{grid-area:1/2}#mw-dpad .l{grid-area:2/1}#mw-dpad .r{grid-area:2/3}#mw-dpad .d{grid-area:3/2}" +
    "#mw-dpad-safe{position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;" +
    "padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)}";
  var pad = document.createElement("div"), safe = document.createElement("div"), mode = "", btns = [];
  pad.id = "mw-dpad"; safe.id = "mw-dpad-safe";
  [["u", "▲", 38], ["l", "◀", 37], ["r", "▶", 39], ["d", "▼", 40]].forEach(function (b) {
    var bt = document.createElement("button"), kc = b[2], t1 = 0, t2 = 0;
    bt.type = "button"; bt.className = b[0]; bt.textContent = b[1]; bt.setAttribute("aria-label", NAMES[kc]);
    function down(e) {
      e.preventDefault(); e.stopPropagation();
      if (bt.classList.contains("on")) return;
      bt.classList.add("on"); fire("keydown", kc);
      if (mode === "world") {                  // like a held key: keep walking
        t1 = setTimeout(function () { t2 = setInterval(function () { if (mode === "world") fire("keydown", kc); }, 170); }, 380);
      }
    }
    function up(e) {
      if (e) { e.preventDefault(); e.stopPropagation(); }
      if (!bt.classList.contains("on")) return;
      bt.classList.remove("on"); clearTimeout(t1); clearInterval(t2); fire("keyup", kc);
    }
    bt.__mwUp = up;
    bt.addEventListener("pointerdown", down); bt.addEventListener("pointerup", up);
    bt.addEventListener("pointercancel", up); bt.addEventListener("lostpointercapture", up);
    ["touchstart", "touchend", "mousedown", "click", "contextmenu"].forEach(function (t) {
      bt.addEventListener(t, function (e) { if (e.cancelable) e.preventDefault(); e.stopPropagation(); });
    });
    btns.push(bt); pad.appendChild(bt);
  });

  function want() {                            // which arrow-key part of the game is on screen?
    try {
      if (typeof Engine == "undefined" || !Engine.activeModule || Engine.keyLock) return "";
      if (typeof Events != "undefined" && Events.activeEvent && Events.activeEvent()) return "";
      if (typeof World != "undefined" && Engine.activeModule === World && !World.dead) return "world";
      if (typeof Space != "undefined" && Engine.activeModule === Space && !Space.done) return "space";
    } catch (e) {}
    return "";
  }
  function hit(a, b) { return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom; }
  function place() {
    var vv = window.visualViewport, s = vv && vv.scale > 0 ? vv.scale : 1;
    var ox = vv ? vv.offsetLeft : 0, oy = vv ? vv.offsetTop : 0, w = vv ? vv.width : innerWidth, h = vv ? vv.height : innerHeight;
    var cs = getComputedStyle(safe), sl = parseFloat(cs.paddingLeft) || 0, sb = parseFloat(cs.paddingBottom) || 0;
    var u = 1 / s, size = (3 * BTN + 2 * GAP) * u;
    pad.style.setProperty("--u", u + "px");
    var left = ox + sl + EDGE * u, top = oy + h - sb - EDGE * u - size;
    // stay clear of the game's own fixed controls at the bottom (menu: restart, save …; logo link) and «✕ Zurück»
    var box = {left: left, top: top, right: left + size, bottom: top + size};
    ["div.menu", "a.logo", "#mw-back"].forEach(function (q) {
      var el = document.querySelector(q);
      if (!el || getComputedStyle(el).display === "none") return;
      var r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0 && hit(box, r)) { top = Math.min(top, r.top - 8 * u - size); box.top = top; box.bottom = top + size; }
    });
    pad.style.left = Math.round(left) + "px"; pad.style.top = Math.round(Math.max(oy, top)) + "px";
    if (w < size) pad.style.left = Math.round(ox) + "px";
  }
  function tick() {
    var m = want();
    if (m !== mode) {
      if (!m) btns.forEach(function (b) { b.__mwUp(); });   // never leave a key «held»
      mode = m;
      pad.classList.toggle("on", !!m);
    }
    if (m) place();
  }
  function start() {
    document.head.appendChild(css); document.body.appendChild(safe); document.body.appendChild(pad);
    setInterval(tick, 200); tick();
    var again = function () { if (mode) place(); };
    if (window.visualViewport) { visualViewport.addEventListener("resize", again); visualViewport.addEventListener("scroll", again); }
    addEventListener("resize", again); addEventListener("orientationchange", function () { setTimeout(again, 300); });
  }
  if (document.body) start(); else addEventListener("DOMContentLoaded", start);
})();
