// Quantum game previews: everything the games share, the same way the "I'm Bored" games in Quantum
// Client share QuantumGameScreen. A game calls Q.game({...}) with:
//   id, title, blurb, controls: [..], width, height (its world, drawn scaled into the field)
//   reset(g)            new game
//   update(g, dt)       while playing
//   idle(g, dt)         every frame (stars, animations), optional
//   draw(g, c)          draws the field (c = 2D context, world units)
//   score(g), stats(g) -> ["Rocks 3", ...], overLines(g) -> [...], options(g, el) for the start card
//   key(g, code, down), mouse(g, button, down), optional
// The theme (Quantum's accent colours) is picked on the start page and kept in localStorage.
'use strict';

const Q = (() => {
  const THEMES = {
    quantum: ['#FF7A1A', '#E0540A'], lava: ['#FF4400', '#CC2200'], arctic: ['#00BBFF', '#0055CC'],
    jade: ['#44FF88', '#008833'], neon: ['#FF00AA', '#990055'], gold: ['#FFCC00', '#BB8800'],
    mint: ['#00FFDD', '#007766'], void: ['#BB44FF', '#660099'], rose: ['#FF2255', '#990033'],
  };
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch { /* private window: not kept */ } },
  };
  const themeName = THEMES[store.get('quantum-theme', 'quantum')] ? store.get('quantum-theme', 'quantum') : 'quantum';
  const [ACC, ACC2] = THEMES[themeName];
  document.documentElement.style.setProperty('--acc', ACC);
  document.documentElement.style.setProperty('--acc2', ACC2);

  // ── small helpers ──────────────────────────────────────────────────
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const rand = (a, b) => a + Math.random() * (b - a);
  const pick = arr => arr[Math.floor(Math.random() * arr.length)];
  const dist = (x1, y1, x2, y2) => Math.hypot(x1 - x2, y1 - y2);
  function rgba(hex, a) {
    const n = parseInt(hex.slice(1), 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  }
  function mix(h1, h2, t) {
    const a = parseInt(h1.slice(1), 16), b = parseInt(h2.slice(1), 16);
    const ch = s => Math.round(lerp((a >> s) & 255, (b >> s) & 255, t));
    return '#' + ((1 << 24) | (ch(16) << 16) | (ch(8) << 8) | ch(0)).toString(16).slice(1);
  }
  const best = id => +store.get('quantum-best-' + id, 0) || 0;

  // ── the starfield behind everything (like Quantum's menu background) ──
  function stars() {
    const cv = document.createElement('canvas');
    cv.id = 'q-stars';
    document.body.prepend(cv);
    const c = cv.getContext('2d');
    const pts = Array.from({ length: 140 }, () => ({ x: Math.random(), y: Math.random(), s: rand(0.6, 1.8), p: rand(0, 6.28) }));
    (function frame(t) {
      const w = cv.width = innerWidth, h = cv.height = innerHeight;
      const g = c.createRadialGradient(w * 0.5, h * 0.42, 0, w * 0.5, h * 0.42, Math.max(w, h) * 0.7);
      g.addColorStop(0, rgba(ACC, 0.08)); g.addColorStop(1, 'rgba(0,0,0,0)');
      c.fillStyle = '#050508'; c.fillRect(0, 0, w, h);
      c.fillStyle = g; c.fillRect(0, 0, w, h);
      for (const p of pts) {
        p.y += p.s * 0.00006; if (p.y > 1) { p.y = 0; p.x = Math.random(); }
        const a = 0.25 + 0.35 * Math.sin(t / 700 + p.p);
        c.fillStyle = Math.random() < 0.002 ? rgba(ACC, 0.9) : `rgba(220,230,255,${a})`;
        c.fillRect(Math.round(p.x * w), Math.round(p.y * h), Math.ceil(p.s), Math.ceil(p.s));
      }
      requestAnimationFrame(frame);
    })(0);
  }

  // ── a game ─────────────────────────────────────────────────────────
  function game(def) {
    stars();
    const W = def.width || 960, H = def.height || 600;
    document.title = def.title + ' - Quantum Games';
    const wrap = el('div', 'q-wrap');
    wrap.innerHTML = `
      <div class="q-panel">
        <div class="q-topline"></div>
        <div class="q-head"><h1>${def.title}</h1><div class="q-chips"></div><a class="q-btn" href="index.html">Back</a></div>
        <div class="q-field"><canvas></canvas>
          <div class="q-shade" data-card="ready"></div>
          <div class="q-shade hidden" data-card="paused"></div>
          <div class="q-shade hidden" data-card="over"></div>
        </div>
        <div class="q-foot"><span class="hint"></span><span class="esc"></span></div>
      </div>`;
    document.body.append(wrap);
    const field = wrap.querySelector('.q-field'), cv = field.querySelector('canvas'), c = cv.getContext('2d');
    const chipsEl = wrap.querySelector('.q-chips');
    const cards = Object.fromEntries([...field.querySelectorAll('.q-shade')].map(e => [e.dataset.card, e]));
    // "W / Left click  orbit out": the keys, two spaces, what they do
    const keyHtml = k => k.replace(/^(.*?)  (.*)$/, '<span class="k">$1</span> $2');
    wrap.querySelector('.hint').innerHTML = def.controls.map(keyHtml).join('<span class="sep"> · </span>');

    const g = {
      W, H, t: 0, state: 'ready', shake: 0, flash: 0, flashColor: '#FFF4DC',
      keys: new Set(), mouse: { x: W / 2, y: H / 2, down: [false, false, false] },
      parts: [], floats: [], data: {}, ACC, ACC2,
      burst(x, y, color, n = 12, speed = 200, life = 0.6, size = 6) {
        for (let i = 0; i < n; i++) {
          const a = rand(0, Math.PI * 2), sp = speed * rand(0.3, 1), l = life * rand(0.5, 1);
          g.parts.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: l, max: l, size: size * rand(0.5, 1), color });
        }
      },
      float(text, x, y, color = ACC) { g.floats.push({ text, x, y, life: 1, color }); },
      over() {
        if (g.state === 'over') return;
        g.state = 'over';
        const sc = def.score(g), old = best(def.id);
        g.newBest = sc > old;
        if (g.newBest) store.set('quantum-best-' + def.id, sc);
        showCard('over');
      },
      start,
    };

    // field size: as big as fits, keeping the game's shape
    function fit() {
      const maxW = innerWidth - 32 - 30, maxH = innerHeight - 32 - 110;
      let w = Math.min(maxW, maxH * W / H), h = w * H / W;
      w = Math.max(320, Math.floor(w)); h = Math.floor(w * H / W);
      field.style.width = w + 'px'; field.style.height = h + 'px';
      const dpr = window.devicePixelRatio || 1;
      cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
    }
    addEventListener('resize', fit);
    fit();

    // cards
    function showCard(name) {
      for (const [k, e] of Object.entries(cards)) e.classList.toggle('hidden', k !== name);
      const e = cards[name];
      if (!e) return;
      if (name === 'ready') {
        e.innerHTML = `<div class="q-card"><h2>${def.title}</h2><div class="blurb">${def.blurb}</div>
          <ul>${def.controls.map(k => `<li>${keyHtml(k)}</li>`).join('')}</ul><div class="opts"></div>
          <button class="q-btn accent play">Play</button><div class="best">Best score: ${best(def.id)}</div></div>`;
        if (def.options) def.options(g, e.querySelector('.opts'));
        e.querySelector('.play').onclick = start;
      } else if (name === 'paused') {
        e.innerHTML = `<div class="q-card"><h2 class="center">Paused</h2>
          <button class="q-btn accent play">Resume</button><button class="q-btn quit">Quit game</button></div>`;
        e.querySelector('.play').onclick = pause;
        e.querySelector('.quit').onclick = () => { g.state = 'ready'; showCard('ready'); };
      } else if (name === 'over') {
        const lines = def.overLines ? def.overLines(g) : [];
        e.innerHTML = `<div class="q-card"><h2 class="over-title">Game over</h2><div class="big">${def.score(g)}</div>
          ${g.newBest ? '<div class="newbest">New best score!</div>' : `<div class="center" style="color:var(--muted)">Best: ${best(def.id)}</div>`}
          ${lines.map(l => `<div class="center">${l}</div>`).join('')}
          <div class="two"><button class="q-btn accent again">Play again</button><button class="q-btn menu">Menu</button></div></div>`;
        e.querySelector('.again').onclick = start;
        e.querySelector('.menu').onclick = () => { g.state = 'ready'; showCard('ready'); };
      }
    }
    function start() {
      g.parts.length = 0; g.floats.length = 0; g.shake = 0; g.flash = 0; g.newBest = false;
      def.reset(g);
      g.state = 'playing';
      showCard(null);
    }
    function pause() {
      if (g.state === 'playing') { g.state = 'paused'; showCard('paused'); }
      else if (g.state === 'paused') { g.state = 'playing'; showCard(null); }
    }

    // input
    addEventListener('keydown', e => {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
      if (e.repeat) return;
      if (e.code === 'Escape' || e.code === 'KeyP') { pause(); return; }
      if ((e.code === 'Enter' || e.code === 'Space') && (g.state === 'ready' || g.state === 'over')) { start(); return; }
      g.keys.add(e.code);
      if (g.state === 'playing' && def.key) def.key(g, e.code, true);
    });
    addEventListener('keyup', e => { g.keys.delete(e.code); if (g.state === 'playing' && def.key) def.key(g, e.code, false); });
    addEventListener('blur', () => { g.keys.clear(); g.mouse.down = [false, false, false]; if (g.state === 'playing') pause(); });
    const toWorld = e => {
      const r = cv.getBoundingClientRect();
      g.mouse.x = (e.clientX - r.left) / r.width * W;
      g.mouse.y = (e.clientY - r.top) / r.height * H;
    };
    addEventListener('mousemove', toWorld);
    cv.addEventListener('mousedown', e => { toWorld(e); g.mouse.down[e.button] = true; if (g.state === 'playing' && def.mouse) def.mouse(g, e.button, true); });
    addEventListener('mouseup', e => { g.mouse.down[e.button] = false; if (g.state === 'playing' && def.mouse) def.mouse(g, e.button, false); });
    cv.addEventListener('contextmenu', e => e.preventDefault());

    // header chips (only touched when they change)
    let lastChips = '';
    function chips() {
      const list = g.state === 'ready' ? [`Best ${best(def.id)}`] : [`Score ${def.score(g)}`, ...(def.stats ? def.stats(g) : [])];
      const key = list.join('|');
      if (key === lastChips) return;
      lastChips = key;
      chipsEl.innerHTML = list.map((t, i) => `<span class="q-chip${i === 0 && g.state !== 'ready' ? ' main' : ''}">${t}</span>`).join('');
    }

    window.quantumGame = g;     // handy in the browser console
    def.reset(g);
    showCard('ready');
    let last = performance.now();
    function tick(now) {
      const dt = Math.max(0, Math.min(0.05, (now - last) / 1000));
      last = Math.max(last, now);
      g.t += dt;
      g.dt = dt;
      if (g.state === 'playing') def.update(g, dt);
      if (def.idle) def.idle(g, dt);
      for (let i = g.parts.length - 1; i >= 0; i--) {
        const p = g.parts[i];
        p.x += p.vx * dt; p.y += p.vy * dt;
        const d = Math.pow(0.95, dt * 60); p.vx *= d; p.vy *= d;
        if ((p.life -= dt) <= 0) g.parts.splice(i, 1);
      }
      for (let i = g.floats.length - 1; i >= 0; i--) if ((g.floats[i].life -= dt * 1.1) <= 0) g.floats.splice(i, 1);
      g.shake = Math.max(0, g.shake - dt * 2.5);
      g.flash = Math.max(0, g.flash - dt * 2.8);
      document.querySelector('.esc').textContent = g.state === 'playing' ? 'Esc  pause' : '';

      // draw: the field in world units, shaken when something big happens
      const s = cv.width / W;
      c.setTransform(1, 0, 0, 1, 0, 0);
      c.fillStyle = '#070709'; c.fillRect(0, 0, cv.width, cv.height);
      c.setTransform(s, 0, 0, s, 0, 0);
      c.imageSmoothingEnabled = false;
      c.save();
      if (g.shake > 0) c.translate(Math.sin(g.t * 90) * g.shake * 9, Math.cos(g.t * 77) * g.shake * 7);
      def.draw(g, c);
      for (const p of g.parts) {
        const l = p.life / p.max, sz = Math.max(1.5, p.size * l);
        c.globalAlpha = l; c.fillStyle = p.color; c.fillRect(p.x - sz / 2, p.y - sz / 2, sz, sz);
      }
      c.globalAlpha = 1;
      c.textAlign = 'center';
      for (const f of g.floats) {
        c.globalAlpha = Math.min(1, f.life * 2);
        c.font = '22px "Pixelify Sans", monospace';
        c.fillStyle = f.color;
        c.fillText(f.text, f.x, f.y - (1 - f.life) * 40);
      }
      c.globalAlpha = 1; c.textAlign = 'left';
      c.restore();
      if (g.flash > 0) { c.fillStyle = g.flashColor; c.globalAlpha = 0.6 * g.flash * g.flash; c.fillRect(0, 0, W, H); c.globalAlpha = 1; }
      chips();
    }
    function frame(now) { tick(now); requestAnimationFrame(frame); }
    requestAnimationFrame(frame);    // after the game's own script has run to its end
    // runs the game forward by hand, e.g. quantumAdvance(2) = two seconds (testing in a hidden tab)
    window.quantumAdvance = seconds => { for (let i = 0; i < Math.ceil(seconds / 0.02); i++) tick(last + 20); };
    return g;
  }

  function el(tag, cls) { const e = document.createElement(tag); if (cls) e.className = cls; return e; }

  // pixel art in several colours: rows of characters, palette = { char: colour }, one square per pixel
  function sprite(c, rows, palette, x, y, px) {
    for (let r = 0; r < rows.length; r++)
      for (let k = 0; k < rows[r].length; k++) {
        const col = palette[rows[r][k]];
        if (!col) continue;
        c.fillStyle = col;
        c.fillRect(x + k * px, y + r * px, px + 0.05, px + 0.05);
      }
  }

  // a ring of pixel squares (shock waves, orbits)
  function ring(c, cx, cy, r, size, color, gap = 0.8) {
    if (r < 2) return;
    const n = Math.max(16, Math.floor(Math.PI * 2 * r / (size * gap)));
    c.fillStyle = color;
    for (let i = 0; i < n; i++) {
      const a = Math.PI * 2 * i / n;
      c.fillRect(cx + Math.cos(a) * r - size / 2, cy + Math.sin(a) * r - size / 2, size, size);
    }
  }

  // a soft round glow
  function glow(c, x, y, r, color, a = 0.5) {
    const gr = c.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, rgba(color, a)); gr.addColorStop(1, rgba(color, 0));
    c.fillStyle = gr; c.fillRect(x - r, y - r, r * 2, r * 2);
  }

  // the stars inside a field, falling slowly
  function fieldStars(n, W, H) {
    return Array.from({ length: n }, () => ({ x: rand(0, W), y: rand(0, H), s: rand(2, 5), p: rand(0, 6.28) }));
  }
  function drawFieldStars(c, list, t, dt, H, W, vx = 0, vy = 12) {
    for (const s of list) {
      s.x += vx * s.s * dt; s.y += vy * s.s * dt;
      if (s.y > H) { s.y = 0; s.x = rand(0, W); }
      if (s.x < 0) { s.x = W; s.y = rand(0, H); }
      c.globalAlpha = 0.45 + 0.35 * Math.sin(t * 2 + s.p);
      c.fillStyle = '#DCE6FF';
      c.fillRect(s.x, s.y, s.s, s.s);
    }
    c.globalAlpha = 1;
  }

  return { THEMES, themeName, ACC, ACC2, store, best, game, background: stars, sprite, ring, glow, fieldStars, drawFieldStars, clamp, lerp, rand, pick, dist, rgba, mix };
})();
