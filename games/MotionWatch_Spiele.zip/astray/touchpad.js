// Motion Watch – Bildschirm-Tasten für Spiele, die eine Tastatur brauchen (GS-1.3). Nur auf Geräten mit Touch sichtbar.
// <script src="../touchpad.js" data-pad='[["◀",37,"l",1],...]'></script>  [Beschriftung, keyCode, Seite l/r, gedrückt halten (1) / wiederholen (2)]
(function () {
  var me = document.currentScript, cfg = [];
  try { cfg = JSON.parse(me.getAttribute("data-pad") || "[]"); } catch (e) {}
  var touch = ("ontouchstart" in window) || (navigator.maxTouchPoints > 0) || matchMedia("(pointer:coarse)").matches;
  if (!touch || !cfg.length) return;
  var NAMES = {32: " ", 37: "ArrowLeft", 38: "ArrowUp", 39: "ArrowRight", 40: "ArrowDown", 13: "Enter", 27: "Escape"};
  function fire(type, kc) {
    var key = NAMES[kc] || String.fromCharCode(kc).toLowerCase();
    var ev = new KeyboardEvent(type, {key: key, bubbles: true, cancelable: true});
    try { Object.defineProperty(ev, "keyCode", {get: function () { return kc; }}); Object.defineProperty(ev, "which", {get: function () { return kc; }}); } catch (e) {}
    (document.activeElement || document.body || document).dispatchEvent(ev);
  }
  var css = document.createElement("style");
  css.textContent = ".mwpad{position:fixed;bottom:calc(10px + env(safe-area-inset-bottom));display:flex;gap:8px;z-index:99999;touch-action:none;user-select:none;-webkit-user-select:none}" +
    ".mwpad.l{left:10px}.mwpad.r{right:10px}.mwpad button{width:58px;height:58px;border-radius:50%;border:2px solid rgba(255,255,255,.55);background:rgba(20,30,45,.55);color:#fff;font:700 24px system-ui,sans-serif;touch-action:none;-webkit-tap-highlight-color:transparent}" +
    ".mwpad button.on{background:rgba(59,140,255,.75)}.mwpad button.w{width:auto;padding:0 16px;border-radius:32px;font-size:18px}";
  document.head.appendChild(css);
  var sides = {l: document.createElement("div"), r: document.createElement("div")};
  sides.l.className = "mwpad l"; sides.r.className = "mwpad r";
  cfg.forEach(function (b) {
    var bt = document.createElement("button"), kc = b[1], mode = b[3] || 0, t1 = 0, t2 = 0;
    bt.textContent = b[0]; if (b[0].length > 2) bt.className = "w";
    function down(e) { e.preventDefault(); bt.classList.add("on"); fire("keydown", kc);
      if (mode === 2) { t1 = setTimeout(function () { t2 = setInterval(function () { fire("keydown", kc); }, 90); }, 220); } }
    function up(e) { if (e) e.preventDefault(); if (!bt.classList.contains("on")) return; bt.classList.remove("on"); clearTimeout(t1); clearInterval(t2); fire("keyup", kc); }
    bt.addEventListener("pointerdown", down); bt.addEventListener("pointerup", up); bt.addEventListener("pointercancel", up); bt.addEventListener("pointerleave", up);
    bt.addEventListener("contextmenu", function (e) { e.preventDefault(); });
    (sides[b[2]] || sides.r).appendChild(bt);
  });
  function add() { document.body.appendChild(sides.l); document.body.appendChild(sides.r); }
  if (document.body) add(); else addEventListener("DOMContentLoaded", add);
})();
