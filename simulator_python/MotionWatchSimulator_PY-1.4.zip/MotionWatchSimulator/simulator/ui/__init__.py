"""The simulator window."""
