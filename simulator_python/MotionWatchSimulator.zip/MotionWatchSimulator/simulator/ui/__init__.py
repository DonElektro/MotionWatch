"""The simulator window."""
