@echo off
rem Fuer PCs ohne Vulkan-Grafiktreiber oder wenn das Bild schwarz bleibt: einfachere Grafik (OpenGL)
start "" "%~dp0MotionWatch3D.exe" --rendering-driver opengl3 --rendering-method gl_compatibility
