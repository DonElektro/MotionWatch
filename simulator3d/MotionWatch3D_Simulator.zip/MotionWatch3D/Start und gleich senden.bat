@echo off
rem Startet den Simulator und sendet sofort an Motion Watch
start "" "%~dp0MotionWatch3D.exe" -- --stream
