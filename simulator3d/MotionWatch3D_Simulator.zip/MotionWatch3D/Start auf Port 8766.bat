@echo off
rem Anderer Port als 8765 (z.B. wenn schon ein Simulator laeuft)
start "" "%~dp0MotionWatch3D.exe" -- --port 8766
