#!/bin/sh
# MW Sim · 3D on a Raspberry Pi 5 (64 bit, Raspberry Pi OS with desktop): simple graphics, sends to Motion Watch
cd "$(dirname "$0")"
chmod +x MotionWatch3D.arm64
exec ./MotionWatch3D.arm64 -- --no-update --stream --quality simple "$@"
